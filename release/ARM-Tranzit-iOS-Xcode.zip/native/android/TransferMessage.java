package kz.armtranzit.app;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Strict native decoder: only one signed SOL transfer and an ARM session memo are signable. */
public final class TransferMessage {
  private static final String ALPHABET="123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  static String b58(byte[] bytes){BigInteger n=new BigInteger(1,bytes);StringBuilder out=new StringBuilder();while(n.signum()>0){BigInteger[] div=n.divideAndRemainder(BigInteger.valueOf(58));out.append(ALPHABET.charAt(div[1].intValue()));n=div[0];}for(byte b:bytes){if(b!=0)break;out.append('1');}return out.reverse().toString();}
  private static int u8(ByteBuffer b){return Byte.toUnsignedInt(b.get());}
  private static byte[] read(ByteBuffer b,int n){byte[] value=new byte[n];b.get(value);return value;}
  public static String describe(byte[] message,byte[] own){
    try{
      ByteBuffer b=ByteBuffer.wrap(message).order(ByteOrder.LITTLE_ENDIAN);
      if(u8(b)!=1||u8(b)!=0||u8(b)!=2||u8(b)!=4)throw new Exception();
      byte[][] keys=new byte[4][];for(int i=0;i<4;i++)keys[i]=read(b,32);
      if(!Arrays.equals(keys[0],own)||Arrays.equals(keys[0],keys[1]))throw new Exception();
      read(b,32);if(u8(b)!=2)throw new Exception();
      int program=u8(b);if(program<2||program>3||!Arrays.equals(keys[program],new byte[32])||u8(b)!=2||u8(b)!=0||u8(b)!=1||u8(b)!=12||b.getInt()!=2)throw new Exception();
      long amount=b.getLong();if(amount<=0||amount>10_000_000_000L)throw new Exception();
      int memoProgram=u8(b);if(memoProgram<2||memoProgram>3||!b58(keys[memoProgram]).equals("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr")||u8(b)!=0)throw new Exception();
      int size=u8(b);if(size!=78||b.remaining()!=size)throw new Exception();
      String memo=new String(read(b,size),StandardCharsets.UTF_8);
      if(!memo.matches("ARM1:[a-f0-9-]{36}:[a-f0-9-]{36}"))throw new Exception();
      return new java.math.BigDecimal(amount).movePointLeft(9).stripTrailingZeros().toPlainString()+" тестовых SOL\nПолучатель: "+b58(keys[1])+"\nБез денежной стоимости";
    }catch(Exception e){throw new IllegalArgumentException("Подпись запрещена: ожидался учебный перевод SOL с меткой сеанса.");}
  }
}
