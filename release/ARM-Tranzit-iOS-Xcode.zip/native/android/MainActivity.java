package kz.armtranzit.app;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle state){registerPlugin(TranzitPlugin.class);super.onCreate(state);getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);}
}
