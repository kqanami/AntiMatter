import { Buffer } from 'buffer';
import { PublicKey } from '@solana/web3.js';
import { Native,isNative,type NearbyEvent } from './native';
import { type Hello,type Offer,type Role,type RecordItem,type Network,type DemoBlock,NETWORK,DEMO_NETWORK,parseWire,validateOffer,parseAmount,autoCandidate } from './domain';
import { balance,prepare,broadcast,reconcile,recoverIncoming,rpc,checkNetwork } from './solana';
import { readJournal,saveRecord,hasUnresolvedOutgoing } from './journal';
import {readChain,writeChain,verifyChain,makeBlock,appendBlock,labBalance} from './demo-chain';
import {desktopPhone,isDesktopPhone,isLanPhone,phoneStorageKey,uuid} from './runtime';
export type State={address:string;name:string;mode:Network;balance:number|null;balanceAt:number|null;role:Role;active:boolean;endpoint?:string;peer?:Hello;candidates:Record<string,string>;verification?:{endpoint:string;code:string;name:string};verifiedCode?:string;busy:boolean;notice:string;error:string;records:RecordItem[];incoming?:Offer;phase:'idle'|'authorizing'|'pending'|'confirmed'};
export class Engine {
  state:State={address:'',name:localStorage.getItem(phoneStorageKey('arm-name'))||(desktopPhone==='sender'?'Вы':desktopPhone==='receiver'?'Другой телефон':'Участник'),mode:isDesktopPhone||isLanPhone?DEMO_NETWORK:localStorage.getItem('arm-mode')===DEMO_NETWORK?DEMO_NETWORK:NETWORK,balance:null,balanceAt:null,role:desktopPhone==='receiver'?'receive':'send',active:false,candidates:{},busy:false,notice:'Откройте приложение на двух телефонах',error:'',records:[],phase:'idle'};
  private listeners=new Set<()=>void>(); private me?:Hello; private selected?:string; private connectTimer?:ReturnType<typeof setTimeout>; private ack?:{id:string;resolve:()=>void;reject:(e:Error)=>void}; private demoAck?:{id:string;hash:string;resolve:()=>void;reject:(e:Error)=>void}; private demoHead?:DemoBlock[]; private refreshing=false; private poll?:ReturnType<typeof setInterval>;
  subscribe=(fn:()=>void)=>{this.listeners.add(fn);return ()=>{this.listeners.delete(fn);};};
  snapshot=()=>this.state;
  patch=(p:Partial<State>)=>{this.state={...this.state,...p};this.listeners.forEach(f=>f());};
  error=(e:unknown)=>this.patch({error:e instanceof Error?e.message:String(e)});
  async init(){
    try{
      this.patch({records:readJournal()});
      if(!isNative){this.patch({notice:'Предпросмотр интерфейса. Переводы и поиск доступны в приложении на телефоне.'});return;}
      await Native.addListener('nearby',event=>{void this.event(event).catch(this.error);});
      const key=await Native.wallet();
      this.patch({address:new PublicKey(Buffer.from(key.publicKey,'base64')).toBase58()});
      await this.refresh();
      if(isDesktopPhone)await this.start(desktopPhone==='receiver'?'receive':'send');
      this.poll=setInterval(()=>{if(document.visibilityState==='visible')void this.refresh();},15_000);
    }catch(e){this.error(e);}
  }
  async refresh(){
    if(!this.state.address||this.refreshing)return;
    this.refreshing=true;
    try{
      for(const record of this.state.records.filter(r=>r.offer.network===NETWORK&&(r.status==='pending'||r.status==='waiting'))){
        const next=record.direction==='in'?await recoverIncoming(record):await reconcile(record);
        this.patch({records:saveRecord(next)});
        if(record.status!=='confirmed'&&next.status==='confirmed')this.patch({phase:'confirmed',notice:next.direction==='in'?'Зачислено · проверено в Solana':'Перевод подтверждён Solana'});
      }
      if(this.state.mode===DEMO_NETWORK){const chain=await verifyChain(readChain());this.patch({balance:labBalance(chain,this.state.address),balanceAt:Date.now()});}
      else this.patch({balance:await balance(this.state.address),balanceAt:Date.now()});
    }catch(e){this.error(e);}finally{this.refreshing=false;}
  }
  setName(name:string){if(this.state.active)return; const clean=name.replace(/[\p{C}]/gu,'').trim().slice(0,24)||'Участник';localStorage.setItem(phoneStorageKey('arm-name'),clean);this.patch({name:clean});}
  async setMode(mode:Network){if((isDesktopPhone||isLanPhone)&&mode!==DEMO_NETWORK)throw new Error('В браузере доступна только учебная цепь.');if(this.state.busy||hasUnresolvedOutgoing(this.state.records))throw new Error('Сначала проверьте незавершённый перевод.');await this.stop();localStorage.setItem('arm-mode',mode);this.patch({mode,balance:null,phase:'idle',notice:mode===DEMO_NETWORK?'Учебная цепь: операции только между двумя телефонами, без денежной стоимости.':'Solana Devnet: тестовые SOL в настоящей сети.'});await this.refresh();}
  async start(role:Role){
    if(!isNative||!this.state.address||this.state.busy)return;
    await this.stop();
    this.me={kind:'hello',v:1,network:this.state.mode,session:uuid(),address:this.state.address,name:this.state.name,role};
    this.patch({role,active:true,error:'',phase:'idle',notice:role==='send'?'Поднесите телефоны. Ищем получателя…':'Телефон виден отправителю. Оставьте этот экран открытым.'});
    try{await Native.start({role,name:this.state.name});}catch(e){this.patch({active:false});this.error(e);}
  }
  async stop(){clearTimeout(this.connectTimer);this.selected=undefined;this.me=undefined;this.ack?.reject(new Error('Сеанс завершён.'));this.ack=undefined;this.demoAck?.reject(new Error('Сеанс завершён.'));this.demoAck=undefined;this.demoHead=undefined;if(isNative)await Native.stop();this.patch({active:false,peer:undefined,endpoint:undefined,candidates:{},verification:undefined,verifiedCode:undefined,incoming:undefined});}
  async connect(endpoint:string){
    if(this.selected||!this.state.active||Object.keys(this.state.candidates).length!==1)return;
    this.selected=endpoint;clearTimeout(this.connectTimer);
    try{await Native.connect({endpoint});this.patch({notice:'Соединяем телефоны. Сверьте код на обоих экранах.'});}catch(e){this.selected=undefined;this.error(e);}
  }
  async verify(accept:boolean){const v=this.state.verification;if(!v)return;await Native.verify({endpoint:v.endpoint,accept});this.patch({verification:undefined,verifiedCode:accept?v.code:undefined,notice:accept?'Ожидаем подтверждение второго телефона…':'Соединение отклонено.'});if(!accept)this.selected=undefined;}
  private async send(data:unknown,endpoint=this.state.endpoint){if(!endpoint)throw new Error('Телефон отключился.');await Native.send({endpoint,data:JSON.stringify(data)});}
  private async event(e:NearbyEvent){
    if(e.type==='error'){this.error(e.message||'Ошибка Nearby');return;}
    if(e.type==='stopped'){this.me=undefined;this.selected=undefined;this.patch({active:false,peer:undefined,endpoint:undefined,verification:undefined,candidates:{}});return;}
    if(!this.state.active)return;
    if(e.type==='found'&&e.endpoint){const candidates={...this.state.candidates,[e.endpoint]:e.name||'Участник'};this.patch({candidates});clearTimeout(this.connectTimer);this.connectTimer=setTimeout(()=>{const id=autoCandidate(Object.keys(this.state.candidates));if(id&&!this.selected)void this.connect(id);},1800);}
    if(e.type==='lost'&&e.endpoint){const candidates={...this.state.candidates};delete candidates[e.endpoint];this.patch({candidates});if(!this.selected){const id=autoCandidate(Object.keys(candidates));if(id)this.connectTimer=setTimeout(()=>{void this.connect(id);},1800);}}
    if(e.type==='verify'&&e.endpoint&&e.code){this.selected=e.endpoint;this.patch({verification:{endpoint:e.endpoint,code:e.code,name:e.name||this.state.candidates[e.endpoint]||'Участник'}});}
    if(e.type==='connected'&&e.endpoint){this.patch({endpoint:e.endpoint,verification:undefined,notice:'Обмениваемся данными кошельков…'});await this.send(this.me,e.endpoint);}
    if(e.type==='disconnected'&&e.endpoint===this.selected){this.selected=undefined;this.ack?.reject(new Error('Телефон отключился.'));this.demoAck?.reject(new Error('Телефон отключился.'));this.patch({peer:undefined,endpoint:undefined,verification:undefined,verifiedCode:undefined,notice:'Связь прервана. Проверьте результат перевода в истории.'});}
    if(e.type==='data'&&e.endpoint===this.state.endpoint&&e.data&&this.me){
      const data=parseWire(e.data);
      if(data.kind==='hello'){
        if(data.address===this.me.address||data.role===this.me.role||data.network!==this.me.network)throw new Error('Нужен другой кошелёк, та же сеть и противоположный режим.');
        if(this.state.peer&&JSON.stringify(this.state.peer)!==JSON.stringify(data))throw new Error('Данные получателя изменились. Начните новый сеанс.');
        this.patch({peer:data,notice:this.state.role==='send'?'Получатель проверен. Ведите светящийся объект вверх.':'Соединение проверено. Ожидаем перевод.'});
      }
      if(data.kind==='offer'&&this.state.peer){
        validateOffer(data,this.me,this.state.peer);
        const existing=this.state.records.find(r=>r.offer.id===data.id);
        if(existing&&JSON.stringify(existing.offer)!==JSON.stringify(data))throw new Error('Повторный идентификатор с другими данными.');
        if(!existing)this.patch({records:saveRecord({offer:data,status:'waiting',direction:'in',created:Date.now()})});
        this.patch({incoming:data,phase:'pending',notice:data.network===DEMO_NETWORK?'Получено событие учебной передачи. Ждём подписанный блок.':'Отправитель подтверждает перевод. Зачисления пока нет.'});
        if(data.network===DEMO_NETWORK)await this.send({kind:'demo-head',id:data.id,chain:await verifyChain(readChain())});
        await this.send({kind:'ack',id:data.id});
      }
      if(data.kind==='ack'&&this.ack?.id===data.id)this.ack.resolve();
      if(data.kind==='demo-head'){const r=this.state.records.find(x=>x.offer.id===data.id);if(this.me.role!=='send'||r)throw new Error('Лишние данные учебной цепи.');this.demoHead=await verifyChain(data.chain);}
      if(data.kind==='demo-block'){
        const r=this.state.records.find(x=>x.offer.id===data.id&&x.direction==='in'&&x.offer.network===DEMO_NETWORK);
        if(!r||!this.state.peer||r.offer.from!==this.state.peer.address||r.offer.to!==this.me.address||data.block.payload.id!==r.offer.id||data.block.payload.from!==r.offer.from||data.block.payload.to!==r.offer.to||data.block.payload.lamports!==r.offer.lamports)throw new Error('Учебный блок не соответствует предложенному переводу.');
        const local=await verifyChain(readChain());const remote=await verifyChain(data.chain);
        if(local.length&&remote.length&&local[local.length-1].hash!==remote[remote.length-1].hash)throw new Error('Учебные цепи разошлись. Перевод заблокирован.');
        if(!local.length&&remote.length)writeChain(remote);
        const next=await appendBlock(readChain(),data.block);
        this.patch({records:saveRecord({...r,signature:data.block.signature,raw:JSON.stringify(data.block),status:'confirmed'}),balance:labBalance(next,this.me.address),balanceAt:Date.now(),phase:'confirmed',notice:'Учебный блок проверен и добавлен. Реальные деньги не переводились.'});
        await this.send({kind:'demo-accepted',id:data.id,hash:data.block.hash});
      }
      if(data.kind==='demo-accepted'&&this.demoAck?.id===data.id&&this.demoAck.hash===data.hash)this.demoAck.resolve();
      if(data.kind==='cancel'){
        const r=this.state.records.find(x=>x.offer.id===data.id&&x.direction==='in'&&x.status==='waiting');
        if(r)this.patch({records:saveRecord({...r,status:'failed',error:'Отправитель отменил. Деньги не переводились.'}),incoming:undefined,phase:'idle'});
      }
      if(data.kind==='receipt'){
        const r=this.state.records.find(r=>r.offer.id===data.id&&r.direction==='in');
        if(!r||r.offer.from!==this.state.peer?.address||r.offer.receiverSession!==this.me.session)throw new Error('Квитанция без согласованного перевода.');
        if(r.signature&&r.signature!==data.signature)throw new Error('Подпись перевода изменилась.');
        this.patch({records:saveRecord({...r,signature:data.signature,status:r.status==='confirmed'?'confirmed':'pending'})});void this.refresh();
      }
    }
  }
  async transfer(amount:string){
    if(this.state.busy)return;
    this.patch({busy:true,error:'',phase:'authorizing'});
    let offer:Offer|undefined;let signed=false;
    try{
      if(hasUnresolvedOutgoing(this.state.records))throw new Error('Сначала проверьте незавершённый перевод в истории. Повторная отправка заблокирована.');
      const peer=this.state.peer,me=this.me,endpoint=this.state.endpoint;
      if(!peer||!me||!endpoint||me.role!=='send')throw new Error('Сначала соедините телефоны и сверьте код.');
      if(Object.keys(this.state.candidates).length>1)throw new Error('Рядом несколько получателей. Отойдите с нужным человеком и повторите.');
      offer={kind:'offer',id:uuid(),network:this.state.mode,from:me.address,to:peer.address,senderSession:me.session,receiverSession:peer.session,lamports:parseAmount(amount),expires:Date.now()+120_000};
      const currentOffer=offer;
      await new Promise<void>((resolve,reject)=>{
        const timer=setTimeout(()=>{this.ack=undefined;reject(new Error('Получатель не ответил. Подпись не создана.'));},12_000);
        this.ack={id:currentOffer.id,resolve:()=>{clearTimeout(timer);this.ack=undefined;resolve();},reject:e=>{clearTimeout(timer);this.ack=undefined;reject(e);}};
        void this.send(currentOffer).catch(e=>this.ack?.reject(e));
      });
      if(this.state.peer?.session!==peer.session||this.state.endpoint!==endpoint)throw new Error('Получатель отключился до авторизации.');
      if(offer.network===DEMO_NETWORK){
        const own=await verifyChain(readChain()),remote=this.demoHead;
        if(!remote)throw new Error('Не получили учебную цепь получателя.');
        if(own.length&&remote.length&&own[own.length-1].hash!==remote[remote.length-1].hash)throw new Error('Учебные цепи разошлись. Перевод заблокирован.');
        const prior=own.length?own:remote;
        this.patch({notice:'Подтвердите создание учебного блока на телефоне.'});
        const block=await makeBlock(prior,offer.from,offer.to,offer.lamports,offer.id,async message=>Buffer.from((await Native.signDemo({message:Buffer.from(message).toString('base64')})).signature,'base64'));
        signed=true;
        const record:RecordItem={offer,signature:block.signature,raw:JSON.stringify({block,chain:prior}),status:'pending',direction:'out',created:Date.now()};
        this.patch({records:saveRecord(record),phase:'pending',notice:'Учебный блок передаётся второму телефону. Зачисления пока нет.'});
        await this.sendDemoBlock(record,endpoint);
        return;
      }
      this.patch({notice:'Подтвердите тестовый перевод средствами защиты телефона.'});
      const record=await prepare(offer,async(message,summary)=>Buffer.from((await Native.sign({message:Buffer.from(message).toString('base64'),summary})).signature,'base64'));
      signed=true;
      this.patch({records:saveRecord(record),phase:'pending',notice:'Подпись сохранена. Ожидаем подтверждение Solana…'});
      // The receipt is a pending claim, never proof of credit. Receiver independently verifies RPC.
      await this.send({kind:'receipt',id:offer.id,signature:record.signature},endpoint).catch(()=>{});
      await broadcast(record);
      await this.refresh();
    }catch(e){if(offer&&!signed)await this.send({kind:'cancel',id:offer.id}).catch(()=>{});this.error(e);this.patch({phase:hasUnresolvedOutgoing(this.state.records)?'pending':'idle'});}finally{this.patch({busy:false});}
  }
  private async sendDemoBlock(record:RecordItem,endpoint:string){
    if(!record.raw)throw new Error('Нет сохранённого учебного блока.');
    const {block,chain}=JSON.parse(record.raw) as {block:DemoBlock;chain:DemoBlock[]};
    await new Promise<void>((resolve,reject)=>{
      const timer=setTimeout(()=>{this.demoAck=undefined;reject(new Error('Ответ второго телефона не получен. Учебный блок остаётся неподтверждённым.'));},12_000);
      this.demoAck={id:record.offer.id,hash:block.hash,resolve:()=>{clearTimeout(timer);this.demoAck=undefined;resolve();},reject:e=>{clearTimeout(timer);this.demoAck=undefined;reject(e);}};
      void this.send({kind:'demo-block',id:record.offer.id,block,chain},endpoint).catch(e=>this.demoAck?.reject(e));
    });
    const next=await appendBlock(readChain(),block);
    this.patch({records:saveRecord({...record,status:'confirmed'}),balance:labBalance(next,this.state.address),balanceAt:Date.now(),phase:'pending',notice:'Учебный блок принят вторым телефоном. Показываем результат.'});
    await new Promise(resolve=>setTimeout(resolve,700));
    this.patch({phase:'confirmed',notice:'Учебный блок принят вторым телефоном. Реальные деньги не переводились.'});
  }
  async retry(record:RecordItem){if(this.state.busy)return;this.patch({busy:true,error:''});try{if(record.offer.network===DEMO_NETWORK){if(!this.state.endpoint||this.state.peer?.address!==record.offer.to)throw new Error('Подключите того же получателя для повтора учебного блока.');await this.sendDemoBlock(record,this.state.endpoint);}else{const checked=await reconcile(record);this.patch({records:saveRecord(checked)});if(checked.status==='pending')await broadcast(checked);await this.refresh();}}catch(e){this.error(e);}finally{this.patch({busy:false});}}
  async airdrop(){if(this.state.busy)return;this.patch({busy:true,error:''});try{await checkNetwork();const signature=await rpc<string>('requestAirdrop',[this.state.address,1_000_000_000,{commitment:'confirmed'}]);this.patch({notice:`Запрос тестовых SOL отправлен (${signature.slice(0,8)}…). Баланс обновится после зачисления.`});await this.refresh();}catch{this.patch({error:'Кран Devnet недоступен или исчерпан лимит. Откройте бесплатный faucet.solana.com, скопируйте адрес ниже и выберите Devnet. Покупать SOL не нужно.'});}finally{this.patch({busy:false});}}
}
